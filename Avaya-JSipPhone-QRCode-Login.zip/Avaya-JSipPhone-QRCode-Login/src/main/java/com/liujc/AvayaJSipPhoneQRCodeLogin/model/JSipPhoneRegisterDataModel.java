package com.liujc.AvayaJSipPhoneQRCodeLogin.model;

public class JSipPhoneRegisterDataModel {
	
	private String j100IP;
	private Integer port;
	private String username; //J00 SIP Phone Admin Web useraccount
	private String password; //J00 SIP Phone Admin Web password
	private String sipLoginName;
	private String sipLoginPassword;
	
	// Get & Set j100IP
	public void setJ100IP(String j100IP) {
		
		this.j100IP = j100IP;
	}

	public String getJ100IP() {
		
		return this.j100IP;
	}
	
	// Get & Set port
	public void setPort(Integer port) {
		
		this.port = port;
	}
	
	public Integer getPort() {
		
		return this.port;
	}
	
	// Get & Set username
	public void setUsername(String username) {
		
		this.username = username;
	}
	
	public String getUsername() {
		
		return this.username;
	}
	
	// Get & Set password
	public void setPassword(String password) {
		
		this.password = password;
	}
	
	public String getPassword() {
		
		return this.password;
	}
	
	// Get & Set sipLoginName
	public void setSipLoginName(String sipLoginName) {
		
		this.sipLoginName = sipLoginName;
	}
	
	public String getSipLoginName() {
		
		return this.sipLoginName;
	}
	
	// Get & Set sipLoginPassword
	public void setSipLoginPassword(String sipLoginPassword) {
		
		this.sipLoginPassword = sipLoginPassword;
	}
	
	public String getSipLoginPassword() {
		
		return this.sipLoginPassword;
	}
}
