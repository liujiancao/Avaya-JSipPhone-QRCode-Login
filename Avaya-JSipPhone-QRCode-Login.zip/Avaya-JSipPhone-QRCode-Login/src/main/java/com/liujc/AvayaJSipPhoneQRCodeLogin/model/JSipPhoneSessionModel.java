package com.liujc.AvayaJSipPhoneQRCodeLogin.model;


public class JSipPhoneSessionModel {
	
	  private String J100sessionId;
	  
	  private String J100nonce;
	  
	  public String getJSipPhoneSessionID() {
		    return this.J100sessionId;
		  }
		  
		  public void setJSipPhoneSessionID(String J100sessionId) {
		    this.J100sessionId = J100sessionId;
		  }
		  
		  public String getJSipPhoneNonce() {
		    return this.J100nonce;
		  }
		  
		  public void setJSipPhoneNonce(String J100nonce) {
		    this.J100nonce = J100nonce;
		  }

}
