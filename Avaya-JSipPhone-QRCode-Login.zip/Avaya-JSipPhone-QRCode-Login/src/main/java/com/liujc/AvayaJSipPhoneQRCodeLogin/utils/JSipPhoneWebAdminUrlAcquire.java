package com.liujc.AvayaJSipPhoneQRCodeLogin.utils;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@EnableConfigurationProperties // 启用配置自动注入功能
@PropertySource(value = "classpath:jSipPhoneWebAdmnUrl.properties", encoding = "utf-8") // 指定配置文件及编码
@ConfigurationProperties(prefix = "url") // 指定类对应的配置项前缀
public class JSipPhoneWebAdminUrlAcquire {

		private String index;
		private String login;
		private String register;
		private String unRegister;
		
		public String getIndex() {
			
			return this.index;
		}
		
		public void setIndex(String index) {
			
			this.index = index;
		}
		
		public String getLogin() {
			
			return this.login;
		}
		
		public void setLogin(String login) {
			
			this.login = login;
		}
		
		public String getRegister() {
			
			return this.register;
		}
		
		public void setRegister(String register) {
			
			this.register = register;
		}
		
		public String getUnRegister() {
			
			return this.unRegister;
		}
		
		public void setUnRegister(String unRegister) {
			
			this.unRegister = unRegister;
		}
		
	}

