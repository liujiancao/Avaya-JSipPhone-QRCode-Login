package com.liujc.AvayaJSipPhoneQRCodeLogin.controller;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.liujc.AvayaJSipPhoneQRCodeLogin.model.JSipPhoneRegisterDataModel;
import com.liujc.AvayaJSipPhoneQRCodeLogin.model.JSipPhoneUnRegisterDataModel;
import com.liujc.AvayaJSipPhoneQRCodeLogin.model.ResultBodyModel;
import com.liujc.AvayaJSipPhoneQRCodeLogin.service.JSipPhoneService;
import com.mashape.unirest.http.exceptions.UnirestException;

@Controller
public class JSipPhoneRestFullAPI {
	
	final Logger logger = LoggerFactory.getLogger(JSipPhoneRestFullAPI.class);
	
	@Autowired
	private JSipPhoneService login;
	@Autowired
	private JSipPhoneService register;
	@Autowired 
	private JSipPhoneService unRegister;
	
	//Document pages
	@RequestMapping("/")
	public String mainPages(){
	    return "pages/dashboard.html";
	}
	
	
	@GetMapping("/login")
	@CrossOrigin(origins = "*")
	@ResponseBody
	public String jSipPhonelogin(String j100IP, Integer port,String username,String password) throws UnirestException, IOException {
		
		String loginResult = login.login(j100IP, port, username, password).getJSipPhoneSessionID();
		
	    if(loginResult.equals("Login fail!")) {
	    	return "Login Fail!";
	    }
	    else {
	    	return "login success!";
	    }
	}
	
	//J100 phone register RESTful API
	@GetMapping("/register")
	@CrossOrigin(origins = "*")
	@ResponseBody
	public ResultBodyModel jSipPhoneRegister(String j100IP, Integer port, String username, String password, String sipLoginName, String sipLoginPassword ) throws UnirestException, IOException {
		
		logger.info("GetReg:"+"j100IP="+j100IP+" port="+port+" username="+username+" password="+password+" sipLoginName="+sipLoginName+" sipLoginPassword="+sipLoginPassword);
		
		ResultBodyModel result = register.register(j100IP, port, username, password, sipLoginName, sipLoginPassword);
		
		return result;
		
	}
	
	@PostMapping("/register")
	@CrossOrigin(origins = "*")
	@ResponseBody
	public ResultBodyModel jSipPhoneRegister(@RequestBody JSipPhoneRegisterDataModel jSipPhoneRegisterDataModel ) throws UnirestException, IOException {
		
		ResultBodyModel result = register.register(jSipPhoneRegisterDataModel);
		
		return result;
		
	}
	
	//J100 phone unregister RESTful API
	@GetMapping("/unregister")
	@CrossOrigin(origins = "*")
	@ResponseBody
	public ResultBodyModel jSipPhoneUnRegister(String j100IP, Integer port, String username, String password, String sipUserId ) throws UnirestException, IOException {
		
		logger.info("GetUnReg:"+"j100IP="+j100IP+" port="+port+" username="+username+" password="+password+" sipUserId="+sipUserId);
		
		ResultBodyModel result = unRegister.unRegister(j100IP, port, username, password, sipUserId);
		
		return result;
		
	}
	
	@PostMapping("/unregister")
	@CrossOrigin(origins = "*")
	@ResponseBody
	public ResultBodyModel jSipPhoneUnRegister(@RequestBody JSipPhoneUnRegisterDataModel jSipPhoneUnRegisterDataModel) throws UnirestException, IOException {
		
		ResultBodyModel result = unRegister.unRegister(jSipPhoneUnRegisterDataModel);
		
		return result;
		
	}
}
