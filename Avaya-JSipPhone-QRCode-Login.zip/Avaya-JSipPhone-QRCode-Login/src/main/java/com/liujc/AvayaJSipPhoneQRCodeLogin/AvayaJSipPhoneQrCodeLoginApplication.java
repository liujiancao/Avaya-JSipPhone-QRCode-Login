package com.liujc.AvayaJSipPhoneQRCodeLogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvayaJSipPhoneQrCodeLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(AvayaJSipPhoneQrCodeLoginApplication.class, args);
	}

}
