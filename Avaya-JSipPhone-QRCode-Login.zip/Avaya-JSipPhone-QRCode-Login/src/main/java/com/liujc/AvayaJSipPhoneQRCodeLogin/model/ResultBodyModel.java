package com.liujc.AvayaJSipPhoneQRCodeLogin.model;

import org.springframework.stereotype.Service;

@Service
public class ResultBodyModel {

	/*
	 * The return message is shown below Sample
	 * {
	 *  "timestamp": "2021-04-13T08:23:20.285+00:00",
	 *  "error": "Internal Server Error",
	 *  "message": "",
	 *  "path": "/register"
	 *  }
	 *
	 */
	
    private String timestamp;
    private String status;
    private String error;
    private String message;
    private String path;
	
	//Get & Set timestamp;
	public void setTimestamp(String timestamp) {
		
		this.timestamp = timestamp;
	}
	
	public String getTimestamp() {
		
		return timestamp;	
	}
	
	//Get & Set status;
	public void setStatus(String status) {
		
		this.status = status;
	}
	
	public String getStatus() {
		
		return status;	
	}
	//Get & Set error;
	public void setError(String error) {
		
		this.error = error;
	}
	
	public String getError() {
		
		return error;	
	}
	
	//Get & Set message
	public void setMessage(String message) {
			
		this.message = message;
	}
		
	public String getMessage() {
			
		return this.message;
	}
	
	//Get & Set path;
	public void setPath(String path) {
		
		this.path = path;
	}
	
	public String getPath() {
		
		return path;	
	}
}
