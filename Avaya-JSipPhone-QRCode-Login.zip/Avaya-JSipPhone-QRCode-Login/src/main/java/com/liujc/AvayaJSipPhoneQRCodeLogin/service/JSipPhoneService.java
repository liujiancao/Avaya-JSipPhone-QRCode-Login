package com.liujc.AvayaJSipPhoneQRCodeLogin.service;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.liujc.AvayaJSipPhoneQRCodeLogin.model.JSipPhoneRegisterDataModel;
import com.liujc.AvayaJSipPhoneQRCodeLogin.model.JSipPhoneSessionModel;
import com.liujc.AvayaJSipPhoneQRCodeLogin.model.JSipPhoneUnRegisterDataModel;
import com.liujc.AvayaJSipPhoneQRCodeLogin.model.ResultBodyModel;
import com.liujc.AvayaJSipPhoneQRCodeLogin.utils.JSipPhoneWebAdminUrlAcquire;
import com.liujc.AvayaJSipPhoneQRCodeLogin.utils.PasswordConvert;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

@Service
public class JSipPhoneService {

	final Logger logger = LoggerFactory.getLogger(JSipPhoneService.class);
	
	//Use Autowired to get JSipPhoneWebAdminUrl.properties
	@Autowired
	JSipPhoneWebAdminUrlAcquire jSipPhoneWebAdminUrlAcquire;
	@Autowired
	ResultBodyModel resultBodyModel;
	
	//J100Sip Phone login function
	public JSipPhoneSessionModel login(String j100IP, int port, String username,String password) throws UnirestException, IOException{
		
		JSipPhoneSessionModel jSipPhoneSessionModel = new JSipPhoneSessionModel();
		
		
		//Define J100 Web Admin Url
		String indexUrl = String.format(jSipPhoneWebAdminUrlAcquire.getIndex(), new Object[] { j100IP, Integer.valueOf(port) });
		String loginUrl = String.format(jSipPhoneWebAdminUrlAcquire.getLogin(), new Object[] { j100IP, Integer.valueOf(port) });
		
		//Acquire J100 Web Admin J100sessionId & J100nonce
		Unirest.setTimeouts(3000, 60000);
		HttpResponse<String> indexResponse = Unirest.get(indexUrl).asString();
		indexResponse.getHeaders().get("Set-Cookie").get(0);
		indexResponse.getHeaders().get("Set-Cookie").get(1);
		
		String J100sessionId = indexResponse.getHeaders().get("Set-Cookie").get(0).substring(indexResponse.getHeaders().get("Set-Cookie").get(0).indexOf("=")+1, indexResponse.getHeaders().get("Set-Cookie").get(0).indexOf(";"));
		String J100nonce     = indexResponse.getHeaders().get("Set-Cookie").get(1).substring(indexResponse.getHeaders().get("Set-Cookie").get(1).indexOf("=")+1, indexResponse.getHeaders().get("Set-Cookie").get(1).indexOf(";"));
		
		jSipPhoneSessionModel.setJSipPhoneSessionID(J100sessionId);
		jSipPhoneSessionModel.setJSipPhoneNonce(J100nonce);
		
		//PasswordConvert
		String passwordEncoded = new PasswordConvert(password,J100nonce).encodedPassword();
		
		//Login to J100 Web Admin
		HttpResponse<String> loginResponse = Unirest.post(loginUrl)
											 		.header("Cookie", "J100sessionId="+jSipPhoneSessionModel.getJSipPhoneSessionID()+";"+"J100nonce="+jSipPhoneSessionModel.getJSipPhoneNonce())
											 		.header("Content-Type", "application/x-www-form-urlencoded")
											 		.field(" uname",username)//There’s must a space in front of "uname",otherwise the form are out of order that the login didn’t work
											 		.field("psw", passwordEncoded)
											 		.asString();
		
		//if login success then update J100sessionId
		String updateJ100sessionId;
		
		if (loginResponse.getHeaders().get("Set-Cookie")!= null) {
			updateJ100sessionId = loginResponse.getHeaders().get("Set-Cookie").get(0).substring(loginResponse.getHeaders().get("Set-Cookie").get(0).indexOf("=")+1, loginResponse.getHeaders().get("Set-Cookie").get(0).indexOf(";"));
		
		}
		else {
			updateJ100sessionId = "Login fail!"; 
			
		}
		jSipPhoneSessionModel.setJSipPhoneSessionID(updateJ100sessionId);
				
		Unirest.shutdown();
		return jSipPhoneSessionModel;
		
	}
	
	//J100Sip Phone Sip station register function for HttpGet
	public ResultBodyModel register(String j100IP, int port, String username,String password,String sipLoginName, String sipLoginPassword) throws UnirestException, IOException {
		
		//Define J100 Web Admin register Url
		String registerUrl = String.format(jSipPhoneWebAdminUrlAcquire.getRegister(), new Object[] { j100IP, Integer.valueOf(port) });
		
		//Login to J100 Web Admin get SessionData
		JSipPhoneSessionModel jSipPhoneSessionModel = login(j100IP, port, username, password);
		
		Unirest.setTimeouts(3000, 60000);
		HttpResponse<String> registerResponse = Unirest.post(registerUrl)
													   .header("Cookie", "J100sessionId="+jSipPhoneSessionModel.getJSipPhoneSessionID()+";"+"J100nonce="+jSipPhoneSessionModel.getJSipPhoneNonce())
													   .header("Content-type","application/x-www-form-urlencoded")
													   .field("SipUserAccount", sipLoginName)
													   .field("SipUserid", "")
													   .field("SipUserPassword", sipLoginPassword)
													   .field("XToken", jSipPhoneSessionModel.getJSipPhoneSessionID())
													   .asString();
		
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		resultBodyModel.setMessage(registerResponse.getBody());
		resultBodyModel.setPath("HttpGet:/register");
		resultBodyModel.setTimestamp(simpleDateFormat.format(new Date()));
		
		Unirest.shutdown();	
		return resultBodyModel;
	
	}
	
	//J100Sip Phone Sip station register function for HttpPost
	public ResultBodyModel register(JSipPhoneRegisterDataModel jSipPhoneRegisterDataModel) throws UnirestException, IOException {
		
		//Define J100 Web Admin register Url
		String registerUrl = String.format(jSipPhoneWebAdminUrlAcquire.getRegister(), new Object[] { jSipPhoneRegisterDataModel.getJ100IP(), jSipPhoneRegisterDataModel.getPort() });
				
		//Login to J100 Web Admin get SessionData
		JSipPhoneSessionModel jSipPhoneSessionModel = login(jSipPhoneRegisterDataModel.getJ100IP(), jSipPhoneRegisterDataModel.getPort(), jSipPhoneRegisterDataModel.getUsername(), jSipPhoneRegisterDataModel.getPassword());
		
		Unirest.setTimeouts(3000, 60000);		
		HttpResponse<String> registerResponse = Unirest.post(registerUrl)
													   .header("Cookie", "J100sessionId="+jSipPhoneSessionModel.getJSipPhoneSessionID()+";"+"J100nonce="+jSipPhoneSessionModel.getJSipPhoneNonce())
													   .header("Content-type","application/x-www-form-urlencoded")
													   .field("SipUserAccount",jSipPhoneRegisterDataModel.getSipLoginName() )
													   .field("SipUserid", "")
													   .field("SipUserPassword", jSipPhoneRegisterDataModel.getSipLoginPassword())
													   .field("XToken", jSipPhoneSessionModel.getJSipPhoneSessionID())
													   .asString();

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		resultBodyModel.setMessage(registerResponse.getBody());
		resultBodyModel.setPath("HttpPost:/register");
		resultBodyModel.setTimestamp(simpleDateFormat.format(new Date()));
		
		Unirest.shutdown();	
		return resultBodyModel;
		
	}
	
	//J100Sip Phone Sip station unRegister function for HttpGet
	public ResultBodyModel unRegister(String j100IP, int port, String username,String password,String sipUserId) throws UnirestException, IOException {
			
		//Define J100 Web Admin unRegister Url
		String unRegisterUrl = String.format(jSipPhoneWebAdminUrlAcquire.getUnRegister(), new Object[] { j100IP, port });
			
		//Login to J100 Web Admin get SessionData
		JSipPhoneSessionModel jSipPhoneSessionModel = login(j100IP, port,username, password);
			
		Unirest.setTimeouts(3000, 60000);
		HttpResponse<String> unRegisterResponse = Unirest.post(unRegisterUrl)
														 .header("Cookie", "J100sessionId="+jSipPhoneSessionModel.getJSipPhoneSessionID()+";"+"J100nonce="+jSipPhoneSessionModel.getJSipPhoneNonce())
														 .header("Content-type","application/x-www-form-urlencoded")
														 .field("SipUserId", sipUserId)
														 .field("XToken", jSipPhoneSessionModel.getJSipPhoneSessionID())
														 .asString();
			
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		resultBodyModel.setMessage(unRegisterResponse.getBody());
		resultBodyModel.setPath("HttpPost:/unregister");
		resultBodyModel.setTimestamp(simpleDateFormat.format(new Date()));
			
		Unirest.shutdown();	
		return resultBodyModel;	
			
		}
	
	//J100Sip Phone Sip station unRegister function for HttpPost
	public ResultBodyModel unRegister(JSipPhoneUnRegisterDataModel jSipPhoneUnRegisterDataModel) throws UnirestException, IOException {
		
		//Define J100 Web Admin unRegister Url
		String unRegisterUrl = String.format(jSipPhoneWebAdminUrlAcquire.getUnRegister(), new Object[] { jSipPhoneUnRegisterDataModel.getJ100IP(), jSipPhoneUnRegisterDataModel.getPort() });
		
		//Login to J100 Web Admin get SessionData
		JSipPhoneSessionModel jSipPhoneSessionModel = login(jSipPhoneUnRegisterDataModel.getJ100IP(), jSipPhoneUnRegisterDataModel.getPort(), jSipPhoneUnRegisterDataModel.getUsername(), jSipPhoneUnRegisterDataModel.getPassword());
		
		Unirest.setTimeouts(3000, 60000);
		HttpResponse<String> unRegisterResponse = Unirest.post(unRegisterUrl)
													   .header("Cookie", "J100sessionId="+jSipPhoneSessionModel.getJSipPhoneSessionID()+";"+"J100nonce="+jSipPhoneSessionModel.getJSipPhoneNonce())
													   .header("Content-type","application/x-www-form-urlencoded")
													   .field("SipUserId", jSipPhoneUnRegisterDataModel.getSipUserId())
													   .field("XToken", jSipPhoneSessionModel.getJSipPhoneSessionID())
													   .asString();
		
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		resultBodyModel.setMessage(unRegisterResponse.getBody());
		resultBodyModel.setPath("HttpPost:/unregister");
		resultBodyModel.setTimestamp(simpleDateFormat.format(new Date()));
		
		Unirest.shutdown();	
		return resultBodyModel;	
		
	}
	
	//J100SipPhone Sip station status query
	public String statusQuery() {
		
		//TODO
		return null;
	}
}
